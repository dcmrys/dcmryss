<?php $__env->startSection('title', 'My Transactions'); ?>
<?php $__env->startSection('heading', 'My Transaction History'); ?>
<?php $__env->startSection('subtitle', 'Review your membership applications, renewals, balances, and recorded payments.'); ?>

<?php $__env->startSection('content'); ?>
<?php if(! $member): ?>
    <section class="panel"><div class="empty-state"><h3>No member profile is linked</h3><p>Contact the membership administrator to connect your login with a member profile.</p></div></section>
<?php else: ?>
    <div class="stats-grid member-transaction-stats">
        <article class="stat-card"><div class="stat-label">Total charges</div><div class="stat-value">₱<?php echo e(number_format($totalDue, 2)); ?></div><div class="stat-foot">Across all transactions</div></article>
        <article class="stat-card"><div class="stat-label">Payments recorded</div><div class="stat-value">₱<?php echo e(number_format($totalPaid, 2)); ?></div><div class="stat-foot">Receipts on file</div></article>
        <article class="stat-card"><div class="stat-label">Outstanding balance</div><div class="stat-value">₱<?php echo e(number_format($balance, 2)); ?></div><div class="stat-foot">Remaining across all transactions</div></article>
    </div>

    <section class="panel">
        <div class="panel-heading"><div><h2><?php echo e($member->full_name); ?></h2><p><?php echo e($member->member_number); ?> · <?php echo e($transactions->total()); ?> transaction(s)</p></div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Reference</th><th>Type</th><th>Level</th><th>Due</th><th>Paid</th><th>Balance</th><th>Status</th><th>Membership period</th><th>Payments</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="mono"><?php echo e($transaction->reference_no); ?></td>
                            <td><?php echo e(ucfirst($transaction->type)); ?></td>
                            <td><?php echo e($transaction->level?->name ?? '—'); ?></td>
                            <td>₱<?php echo e(number_format((float) $transaction->amount_due, 2)); ?></td>
                            <td>₱<?php echo e(number_format($transaction->paid_amount, 2)); ?></td>
                            <td>₱<?php echo e(number_format($transaction->balance, 2)); ?></td>
                            <td><span class="badge badge-<?php echo e($transaction->display_status); ?>"><?php echo e(ucfirst($transaction->display_status)); ?></span></td>
                            <td><?php echo e($transaction->starts_on?->format('M j, Y') ?? '—'); ?><?php echo e($transaction->ends_on ? ' – '.$transaction->ends_on->format('M j, Y') : ''); ?></td>
                            <td>
                                <?php if($transaction->payments->isEmpty()): ?>
                                    —
                                <?php else: ?>
                                    <details class="member-payment-details">
                                        <summary><?php echo e($transaction->payments->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('payment', $transaction->payments->count())); ?></summary>
                                        <ul>
                                            <?php $__currentLoopData = $transaction->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><strong><?php echo e($payment->payment_no); ?></strong><span>₱<?php echo e(number_format((float) $payment->amount, 2)); ?> · <?php echo e($payment->paid_at?->format('M j, Y')); ?> · <?php echo e(ucwords(str_replace('_', ' ', $payment->method))); ?></span><?php if($payment->reference): ?><span>Receipt: <?php echo e($payment->reference); ?></span><?php endif; ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </details>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="9"><div class="empty-state"><h3>No transactions yet</h3><p>Application and renewal transactions will appear here.</p></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($transactions->hasPages()): ?>
            <div class="pagination"><span>Showing <?php echo e($transactions->firstItem()); ?>–<?php echo e($transactions->lastItem()); ?> of <?php echo e($transactions->total()); ?></span><div><?php if($transactions->previousPageUrl()): ?><a href="<?php echo e($transactions->previousPageUrl()); ?>">← Previous</a><?php endif; ?> <?php if($transactions->nextPageUrl()): ?><a href="<?php echo e($transactions->nextPageUrl()); ?>">Next →</a><?php endif; ?></div></div>
        <?php endif; ?>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/transactions/mine.blade.php ENDPATH**/ ?>