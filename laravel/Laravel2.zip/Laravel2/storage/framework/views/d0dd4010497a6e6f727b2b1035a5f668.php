<?php $__env->startSection('title', 'Transactions'); ?>
<?php $__env->startSection('heading', 'Transaction Processing'); ?>
<?php $__env->startSection('subtitle', 'Track application fees, renewal charges, payments, approvals, and membership periods.'); ?>
<?php $__env->startSection('actions'); ?>
    <a class="btn btn-outline" href="<?php echo e(route('payments.index')); ?>">Payment register</a>
    <a class="btn btn-primary" href="<?php echo e(route('transactions.create')); ?>">Start renewal</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="stats-grid transaction-stats">
    <?php $__currentLoopData = ['pending' => 'Pending', 'paid' => 'Paid', 'approved' => 'Approved', 'expired' => 'Expired', 'cancelled' => 'Cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="stat-card"><div class="stat-label"><?php echo e($label); ?></div><div class="stat-value"><?php echo e($statusCounts[$status] ?? 0); ?></div><div class="stat-foot">Transactions</div></article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<section class="panel">
    <div class="panel-heading">
        <div><h2>Membership transactions</h2><p>Track applications, registrations, and renewals. Approve fully paid transactions to apply membership dates.</p></div>
        <span class="count-pill"><?php echo e($transactions->total()); ?> total</span>
    </div>
    <form method="GET" action="<?php echo e(route('transactions.index')); ?>" class="filter-bar">
        <input class="search-field" type="search" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Reference, member, or member ID">
        <select name="status" aria-label="Filter transactions by status">
            <option value="">All statuses</option>
            <?php $__currentLoopData = \App\Models\MembershipTransaction::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php if(($filters['status'] ?? '') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn btn-secondary btn-small" type="submit">Filter</button>
        <?php if(request()->hasAny(['search', 'status'])): ?><a class="clear-link" href="<?php echo e(route('transactions.index')); ?>">Clear</a><?php endif; ?>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Transaction reference</th><th>Member</th><th>Type</th><th>Level</th><th>Due</th><th>Paid</th><th>Balance</th><th>Status</th><th>Created</th><th></th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="mono"><a class="table-primary" href="<?php echo e(route('transactions.show', $transaction)); ?>"><?php echo e($transaction->reference_no); ?></a></td>
                        <td><a class="table-primary" href="<?php echo e(route('members.show', $transaction->member)); ?>"><?php echo e($transaction->member->full_name); ?></a><span class="table-secondary"><?php echo e($transaction->member->member_number); ?></span></td>
                        <td><?php echo e(ucfirst($transaction->type)); ?></td>
                        <td><?php echo e($transaction->level->name); ?></td>
                        <td>₱<?php echo e(number_format((float) $transaction->amount_due, 2)); ?></td>
                        <td>₱<?php echo e(number_format($transaction->paid_amount, 2)); ?></td>
                        <td>₱<?php echo e(number_format($transaction->balance, 2)); ?></td>
                        <td><span class="badge badge-<?php echo e($transaction->display_status); ?>"><?php echo e(ucfirst($transaction->display_status)); ?></span></td>
                        <td><?php echo e($transaction->created_at?->format('M j, Y')); ?></td>
                        <td><div class="transaction-row-actions"><a class="btn btn-outline btn-small" href="<?php echo e(route('transactions.show', $transaction)); ?>">View</a><?php if($transaction->status === 'cancelled' && $transaction->payments->isEmpty()): ?><form method="POST" action="<?php echo e(route('transactions.destroy', $transaction)); ?>" onsubmit="return confirm('Permanently delete this cancelled transaction? This cannot be undone.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-danger-outline btn-small" type="submit">Delete</button></form><?php endif; ?></div></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="10"><div class="empty-state"><span>₱</span><h3>No transactions yet</h3><p>Approving a membership application creates its initial transaction. Create renewals from this page.</p></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($transactions->hasPages()): ?>
        <div class="pagination">
            <span>Showing <?php echo e($transactions->firstItem()); ?>–<?php echo e($transactions->lastItem()); ?> of <?php echo e($transactions->total()); ?></span>
            <div><?php if($transactions->previousPageUrl()): ?><a href="<?php echo e($transactions->previousPageUrl()); ?>">← Previous</a><?php endif; ?> <?php if($transactions->nextPageUrl()): ?><a href="<?php echo e($transactions->nextPageUrl()); ?>">Next →</a><?php endif; ?></div>
        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/transactions/index.blade.php ENDPATH**/ ?>