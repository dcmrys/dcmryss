<?php $__env->startSection('title', 'Payments'); ?>
<?php $__env->startSection('heading', 'Payment Register'); ?>
<?php $__env->startSection('subtitle', 'Review all recorded membership payments and their transaction references.'); ?>
<?php $__env->startSection('actions'); ?><a class="btn btn-outline" href="<?php echo e(route('transactions.index')); ?>">← Transactions</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading"><div><h2>Recorded payments</h2><p>Payments are immutable records linked to membership transactions.</p></div><span class="count-pill"><?php echo e($payments->total()); ?> total</span></div>
    <form method="GET" action="<?php echo e(route('payments.index')); ?>" class="filter-bar">
        <input class="search-field" type="search" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Payment reference, transaction, or member">
        <select name="method" aria-label="Filter payments by method">
            <option value="">All methods</option>
            <?php $__currentLoopData = ['cash' => 'Cash', 'bank_transfer' => 'Bank transfer', 'gcash' => 'GCash', 'card' => 'Card', 'other' => 'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php if(($filters['method'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn btn-secondary btn-small" type="submit">Filter</button>
        <?php if(request()->hasAny(['search', 'method'])): ?><a class="clear-link" href="<?php echo e(route('payments.index')); ?>">Clear</a><?php endif; ?>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Payment number</th><th>Transaction</th><th>Member</th><th>Method</th><th>Receipt reference</th><th>Paid on</th><th>Amount</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="mono"><?php echo e($payment->payment_no); ?></td>
                        <td class="mono"><a class="table-primary" href="<?php echo e(route('transactions.show', $payment->transaction)); ?>"><?php echo e($payment->transaction->reference_no); ?></a></td>
                        <td><a class="table-primary" href="<?php echo e(route('members.show', $payment->transaction->member)); ?>"><?php echo e($payment->transaction->member->full_name); ?></a></td>
                        <td><?php echo e(ucwords(str_replace('_', ' ', $payment->method))); ?></td>
                        <td><?php echo e($payment->reference ?: '—'); ?></td>
                        <td><?php echo e($payment->paid_at?->format('M j, Y')); ?></td>
                        <td>₱<?php echo e(number_format((float) $payment->amount, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7"><div class="empty-state"><span>₱</span><h3>No payments yet</h3><p>Recorded payments will appear here with their transaction and member details.</p></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($payments->hasPages()): ?>
        <div class="pagination"><span>Showing <?php echo e($payments->firstItem()); ?>–<?php echo e($payments->lastItem()); ?> of <?php echo e($payments->total()); ?></span><div><?php if($payments->previousPageUrl()): ?><a href="<?php echo e($payments->previousPageUrl()); ?>">← Previous</a><?php endif; ?> <?php if($payments->nextPageUrl()): ?><a href="<?php echo e($payments->nextPageUrl()); ?>">Next →</a><?php endif; ?></div></div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/payments/index.blade.php ENDPATH**/ ?>