<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#260b18">
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/novelle-logo.svg')); ?>?v=3">
    <title><?php echo $__env->yieldContent('title', 'Members'); ?> · <?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/css/burgundy.css', 'resources/js/app.js']); ?>
</head>
<body>
    <div class="app-shell">
        <header class="topbar">
            <a class="brand" href="<?php echo e(route('tasks.index')); ?>" aria-label="Novelle tasks home">
                <img class="brand-mark" src="<?php echo e(asset('images/novelle-logo.svg')); ?>?v=3" alt="">
                <span>Novelle<span class="auth-brand-dot">.</span></span>
            </a>
            <nav class="nav" aria-label="Main navigation">
                <a class="nav-link <?php echo e(request()->routeIs('tasks.*') ? 'active' : ''); ?>" href="<?php echo e(route('tasks.index')); ?>">Tasks</a>
                <a class="nav-link <?php echo e(request()->routeIs('members.*') ? 'active' : ''); ?>" href="<?php echo e(route('members.index')); ?>">Members</a>
                <?php if(auth()->user()->isAdmin()): ?>
                <a class="nav-link <?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>" href="<?php echo e(route('categories.index')); ?>">Membership Categories</a>
                <a class="nav-link <?php echo e(request()->routeIs('levels.*') ? 'active' : ''); ?>" href="<?php echo e(route('levels.index')); ?>">Membership Levels</a>
                <a class="nav-link <?php echo e(request()->routeIs('transactions.*') ? 'active' : ''); ?>" href="<?php echo e(route('transactions.index')); ?>">Transactions</a>
                <a class="nav-link <?php echo e(request()->routeIs('payments.*') ? 'active' : ''); ?>" href="<?php echo e(route('payments.index')); ?>">Payments</a>
                <?php else: ?>
                <a class="nav-link <?php echo e(request()->routeIs('my.transactions') ? 'active' : ''); ?>" href="<?php echo e(route('my.transactions')); ?>">My Transactions</a>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="task-action" type="submit">Sign out</button></form>
            </nav>
        </header>

        <main class="content">
            <div class="page-heading">
                <div>
                    <h1><?php echo $__env->yieldContent('heading', 'Members'); ?></h1>
                    <p class="heading-subtitle"><?php echo $__env->yieldContent('subtitle'); ?></p>
                </div>
                <div class="heading-action"><?php echo $__env->yieldContent('actions'); ?></div>
            </div>

            <?php if(session('success')): ?><div class="alert alert-success" role="status"><span>✓</span> <?php echo e(session('success')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-error" role="alert"><span>!</span><div><strong>Please check the following:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div></div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/layouts/app.blade.php ENDPATH**/ ?>