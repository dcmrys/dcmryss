<?php $__env->startSection('title', 'Transaction '.$transaction->reference_no); ?>
<?php $__env->startSection('heading'); ?>
    <span class="transaction-reference-heading"><?php echo e($transaction->reference_no); ?></span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subtitle', ucfirst($transaction->type).' transaction for '.$transaction->member->full_name); ?>
<?php $__env->startSection('actions'); ?>
    <a class="btn btn-outline" href="<?php echo e(route('transactions.index')); ?>">← Transactions</a>
    <a class="btn btn-outline" href="<?php echo e(route('members.show', $transaction->member)); ?>">Member profile</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="transaction-detail-grid">
    <section class="panel detail-panel">
        <div class="transaction-status-line"><span class="badge badge-<?php echo e($transaction->display_status); ?>"><?php echo e(ucfirst($transaction->display_status)); ?></span><span class="table-secondary">Created <?php echo e($transaction->created_at?->format('M j, Y g:i A')); ?></span></div>
        <dl>
            <div><dt>Member</dt><dd><a href="<?php echo e(route('members.show', $transaction->member)); ?>"><?php echo e($transaction->member->full_name); ?> · <?php echo e($transaction->member->member_number); ?></a></dd></div>
            <div><dt>Category</dt><dd><?php echo e($transaction->category->name); ?></dd></div>
            <div><dt>Level</dt><dd><?php echo e($transaction->level->name); ?></dd></div>
            <div><dt>Transaction type</dt><dd><?php echo e(ucfirst($transaction->type)); ?></dd></div>
            <div><dt>Amount due</dt><dd>₱<?php echo e(number_format((float) $transaction->amount_due, 2)); ?></dd></div>
            <div><dt>Paid</dt><dd>₱<?php echo e(number_format($transaction->paid_amount, 2)); ?></dd></div>
            <div><dt>Balance</dt><dd>₱<?php echo e(number_format($transaction->balance, 2)); ?></dd></div>
            <div><dt>Membership period</dt><dd><?php echo e($transaction->starts_on?->format('M j, Y') ?? 'Not activated'); ?><?php echo e($transaction->ends_on ? ' – '.$transaction->ends_on->format('M j, Y') : ''); ?></dd></div>
            <div><dt>Processed</dt><dd><?php echo e($transaction->processed_at?->format('M j, Y g:i A') ?? 'Not processed'); ?></dd></div>
            <?php if($transaction->notes): ?><div><dt>Notes</dt><dd><?php echo e($transaction->notes); ?></dd></div><?php endif; ?>
        </dl>
        <?php if($transaction->status === 'paid'): ?>
            <form method="POST" action="<?php echo e(route('transactions.approve', $transaction)); ?>" class="transaction-action-form" onsubmit="return confirm('Approve this fully paid transaction and apply its membership dates?')">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button class="btn btn-primary" type="submit">Approve and apply membership</button>
            </form>
        <?php elseif($transaction->status === 'pending' && $transaction->payments->isEmpty()): ?>
            <form method="POST" action="<?php echo e(route('transactions.cancel', $transaction)); ?>" class="transaction-action-form" onsubmit="return confirm('Cancel this transaction?')">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button class="btn btn-danger-outline" type="submit">Cancel transaction</button>
            </form>
        <?php endif; ?>
        <?php if($transaction->status === 'cancelled' && $transaction->payments->isEmpty()): ?>
            <form method="POST" action="<?php echo e(route('transactions.destroy', $transaction)); ?>" class="transaction-action-form" onsubmit="return confirm('Permanently delete this cancelled transaction? This cannot be undone.')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger-outline" type="submit">Delete transaction</button>
            </form>
        <?php endif; ?>
    </section>

    <?php if(in_array($transaction->status, ['pending', 'approved'], true) && $transaction->balance > 0): ?>
        <section class="panel form-panel">
            <div class="section-heading"><span class="section-icon">₱</span><div><h2>Record a payment</h2><p>Remaining balance: ₱<?php echo e(number_format($transaction->balance, 2)); ?>.</p></div></div>
            <form method="POST" action="<?php echo e(route('transactions.payments.store', $transaction)); ?>" class="stacked-form">
                <?php echo csrf_field(); ?>
                <label class="field"><span>Payment amount (₱) <em>*</em></span><input type="number" name="amount" min="0.01" max="<?php echo e(number_format($transaction->balance, 2, '.', '')); ?>" step="0.01" value="<?php echo e(old('amount', number_format($transaction->balance, 2, '.', ''))); ?>" required></label>
                <label class="field"><span>Payment method <em>*</em></span><select name="method" required>
                    <option value="">Choose a method</option>
                    <?php $__currentLoopData = ['cash' => 'Cash', 'bank_transfer' => 'Bank transfer', 'gcash' => 'GCash', 'card' => 'Card', 'other' => 'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(old('method') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select></label>
                <label class="field"><span>External receipt/reference</span><input name="reference" value="<?php echo e(old('reference')); ?>" maxlength="100" placeholder="Optional — generated if blank"></label>
                <label class="field"><span>Payment date <em>*</em></span><input type="date" name="paid_at" value="<?php echo e(old('paid_at', today()->toDateString())); ?>" max="<?php echo e(today()->toDateString()); ?>" required></label>
                <div class="form-actions"><button class="btn btn-primary" type="submit">Record payment</button></div>
            </form>
        </section>
    <?php endif; ?>
</div>

<section class="panel transaction-payments">
    <div class="panel-heading"><div><h2>Payment records</h2><p>Each payment receives a unique payment reference.</p></div><span class="count-pill"><?php echo e($transaction->payments->count()); ?> total</span></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Payment number</th><th>Paid on</th><th>Method</th><th>Receipt reference</th><th>Amount</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transaction->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><td class="mono"><?php echo e($payment->payment_no); ?></td><td><?php echo e($payment->paid_at?->format('M j, Y')); ?></td><td><?php echo e(ucwords(str_replace('_', ' ', $payment->method))); ?></td><td><?php echo e($payment->reference ?: '—'); ?></td><td>₱<?php echo e(number_format((float) $payment->amount, 2)); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5"><div class="empty-state"><h3>No payments recorded</h3><p>Record payment against the remaining balance to move this transaction to Paid.</p></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/transactions/show.blade.php ENDPATH**/ ?>