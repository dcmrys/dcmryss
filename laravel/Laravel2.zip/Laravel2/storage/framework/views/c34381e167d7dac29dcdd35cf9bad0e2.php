
<?php $__env->startSection('title', 'Member profile'); ?>
<?php $__env->startSection('heading', $member->full_name); ?>
<?php $__env->startSection('subtitle', $member->member_number . ' · Joined ' . ($member->joined_at?->format('M j, Y') ?? 'Pending')); ?>
<?php $__env->startSection('actions'); ?><a class="btn btn-outline" href="<?php echo e(route('members.index')); ?>">← Members</a><?php if(auth()->user()->isAdmin()): ?><a class="btn btn-primary" href="<?php echo e(route('members.edit', $member)); ?>">Edit profile</a><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="profile-grid">
    <div class="profile-main">
        <section class="panel profile-hero">
            <div class="profile-identity"><span class="profile-avatar"><?php echo e(strtoupper(substr($member->first_name, 0, 1).substr($member->last_name, 0, 1))); ?></span><div><h2><?php echo e($member->full_name); ?></h2><span class="badge badge-<?php echo e($member->display_status); ?>"><?php echo e(ucfirst($member->display_status)); ?></span></div></div>
            <div class="profile-facts"><div><small>Category</small><strong><?php echo e($member->category->name); ?></strong></div><div><small>Level</small><strong><?php echo e($member->level->name); ?></strong></div><div><small>Valid until</small><strong><?php echo e($member->expires_at?->format('M j, Y') ?? '—'); ?></strong></div></div>
        </section>
        <section class="panel detail-panel"><h2><?php echo e($member->level->name); ?> benefits</h2><p class="note-text"><?php echo e($member->level->benefits ?: 'Benefits to be announced.'); ?></p></section>
    </div>

    <aside class="profile-aside">
        <section class="panel detail-panel"><h2>Member information</h2><dl><div><dt>Email address</dt><dd><a href="mailto:<?php echo e($member->email); ?>"><?php echo e($member->email); ?></a></dd></div><div><dt>Phone number</dt><dd><?php echo e($member->phone ?: '—'); ?></dd></div><div><dt>Address</dt><dd><?php echo e($member->address ?: '—'); ?></dd></div><div><dt>Member since</dt><dd><?php echo e($member->joined_at?->format('M j, Y') ?? 'Pending'); ?></dd></div></dl></section>
        <section class="panel detail-panel"><h2><?php echo e($member->level->name); ?> membership</h2><dl><div><dt>Fee</dt><dd>₱<?php echo e(number_format($member->level->fee, 2)); ?></dd></div><div><dt>Validity</dt><dd><?php echo e($member->level->validity_months); ?> months</dd></div></dl></section>
        <?php if(auth()->user()->isAdmin() && $member->notes): ?><section class="panel detail-panel"><p class="note-text"><?php echo e($member->notes); ?></p></section><?php endif; ?>
        <?php if(auth()->user()->isAdmin()): ?><section class="panel detail-panel"><h2>Manage member</h2><p class="muted">Deactivation keeps the member’s profile available.</p>
            <?php if($member->status === 'inactive'): ?><form method="POST" action="<?php echo e(route('members.reactivate', $member)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-secondary full-width" type="submit">Reactivate member</button></form>
            <?php else: ?><form method="POST" action="<?php echo e(route('members.deactivate', $member)); ?>" onsubmit="return confirm('Deactivate this member?')"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-danger-outline full-width" type="submit">Deactivate member</button></form><?php endif; ?>
            <form method="POST" action="<?php echo e(route('members.destroy', $member)); ?>" class="member-danger-action" onsubmit="return confirm('Permanently delete this member? This cannot be undone.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-danger-outline full-width" type="submit">Delete member</button></form>
        </section><?php endif; ?>
    </aside>
</div>

<?php if($canViewTransactionHistory): ?>
    <section class="panel member-transaction-history">
        <div class="panel-heading">
            <div><h2>Transaction history</h2><p>Membership applications, renewals, and recorded payments.</p></div>
            <span class="count-pill"><?php echo e($member->transactions->count()); ?> total</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Reference</th><th>Type</th><th>Level</th><th>Due</th><th>Paid</th><th>Balance</th><th>Status</th><th>Period</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="mono">
                                <?php if(auth()->user()->isAdmin()): ?>
                                    <a class="table-primary" href="<?php echo e(route('transactions.show', $transaction)); ?>"><?php echo e($transaction->reference_no); ?></a>
                                <?php else: ?>
                                    <?php echo e($transaction->reference_no); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e(ucfirst($transaction->type)); ?></td>
                            <td><?php echo e($transaction->level?->name ?? '—'); ?></td>
                            <td>₱<?php echo e(number_format((float) $transaction->amount_due, 2)); ?></td>
                            <td>₱<?php echo e(number_format($transaction->paid_amount, 2)); ?></td>
                            <td>₱<?php echo e(number_format($transaction->balance, 2)); ?></td>
                            <td><span class="badge badge-<?php echo e($transaction->display_status); ?>"><?php echo e(ucfirst($transaction->display_status)); ?></span></td>
                            <td><?php echo e($transaction->starts_on?->format('M j, Y') ?? '—'); ?><?php echo e($transaction->ends_on ? ' – '.$transaction->ends_on->format('M j, Y') : ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="8"><div class="empty-state"><h3>No transactions yet</h3><p>Application or renewal transactions will appear here.</p></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/members/show.blade.php ENDPATH**/ ?>