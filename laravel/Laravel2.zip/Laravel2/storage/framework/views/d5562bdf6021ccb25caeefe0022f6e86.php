<?php $__env->startSection('title', 'Start Membership Renewal'); ?>
<?php $__env->startSection('eyebrow', 'MEMBERSHIP FINANCE'); ?>
<?php $__env->startSection('heading', 'Start a renewal'); ?>
<?php $__env->startSection('subtitle', 'Create a pending charge. Record payment, then approve it to extend the member’s dates.'); ?>
<?php $__env->startSection('actions'); ?><a class="btn btn-outline" href="<?php echo e(route('transactions.index')); ?>">← Transactions</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="panel form-panel">
    <div class="section-heading"><span class="section-icon">↻</span><div><h2>Renewal details</h2><p>The new period starts after the current membership expires, or today if it is already expired.</p></div></div>
    <?php if($members->isEmpty()): ?>
        <div class="empty-state"><h3>No established members available</h3><p>A member must have an active membership record before a renewal can be created.</p></div>
    <?php else: ?>
        <form method="POST" action="<?php echo e(route('transactions.store')); ?>" class="stacked-form">
            <?php echo csrf_field(); ?>
            <label class="field"><span>Member <em>*</em></span>
                <select name="member_id" required>
                    <option value="">Choose a member</option>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($member->id); ?>" <?php if((string) old('member_id') === (string) $member->id): echo 'selected'; endif; ?>><?php echo e($member->member_number); ?> — <?php echo e($member->full_name); ?> · <?php echo e($member->level?->name ?? 'No level'); ?><?php echo e($member->expires_at ? ' · expires '.$member->expires_at->format('M j, Y') : ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="field"><span>Renewal level <em>*</em></span>
                <select name="membership_level_id" required>
                    <option value="">Choose a level</option>
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>" <?php if((string) old('membership_level_id') === (string) $level->id): echo 'selected'; endif; ?>><?php echo e($level->name); ?> — ₱<?php echo e(number_format((float) $level->fee, 2)); ?> / <?php echo e($level->validity_months); ?> months</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="field"><span>Internal notes</span><textarea name="notes" rows="4" maxlength="2000" placeholder="Optional notes for this renewal"><?php echo e(old('notes')); ?></textarea></label>
            <div class="form-actions"><button class="btn btn-primary" type="submit">Create renewal transaction</button></div>
        </form>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/transactions/create.blade.php ENDPATH**/ ?>