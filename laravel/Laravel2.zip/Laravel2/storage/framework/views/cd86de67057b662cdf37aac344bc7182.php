<?php $__env->startSection('title', 'Membership Categories'); ?>
<?php $__env->startSection('heading', 'Membership Categories'); ?>
<?php $__env->startSection('subtitle', 'Organize members by category. Changes here appear in the member registration form.'); ?>

<?php $__env->startSection('content'); ?>
<div class="catalog-grid">
    <section class="panel catalog-section">
        <div class="panel-heading">
            <div><h2>Categories</h2><p>Edit the name or description of each category.</p></div>
            <span class="count-pill"><?php echo e($categories->count()); ?> total</span>
        </div>
        <div class="catalog-list">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="catalog-item">
                    <form method="POST" action="<?php echo e(route('categories.update', $category)); ?>" class="catalog-form">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="catalog-item-top"><span class="catalog-symbol"><?php echo e(strtoupper(substr($category->name, 0, 1))); ?></span><span class="catalog-meta"><?php echo e($category->members_count); ?> <?php echo e(Str::plural('member', $category->members_count)); ?></span></div>
                        <label class="field"><span>Category name</span><input name="name" value="<?php echo e($category->name); ?>" required maxlength="100"></label>
                        <label class="field"><span>Description</span><textarea name="description" rows="2" maxlength="1000" placeholder="Optional description"><?php echo e($category->description); ?></textarea></label>
                        <div class="form-actions"><button class="btn btn-secondary btn-small" type="submit">Save changes</button></div>
                    </form>
                    <?php if($category->members_count === 0): ?>
                        <form method="POST" action="<?php echo e(route('categories.destroy', $category)); ?>" class="catalog-delete" onsubmit="return confirm('Delete this membership category?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-link">Delete category</button>
                        </form>
                    <?php else: ?>
                        <p class="catalog-use-note">In use by members · cannot be deleted</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="empty-card">No categories yet. Add one using the form.</p>
            <?php endif; ?>
        </div>
    </section>

    <section class="panel form-panel">
        <div class="section-heading"><span class="section-icon">＋</span><div><h2>Add a category</h2><p>Give members another category to choose from.</p></div></div>
        <form method="POST" action="<?php echo e(route('categories.store')); ?>" class="stacked-form">
            <?php echo csrf_field(); ?>
            <label class="field"><span>Category name <em>*</em></span><input name="name" value="<?php echo e(old('name')); ?>" required maxlength="100" placeholder="e.g. Alumni"></label>
            <label class="field"><span>Description</span><textarea name="description" rows="3" maxlength="1000" placeholder="Optional description"><?php echo e(old('description')); ?></textarea></label>
            <div class="form-actions"><button class="btn btn-primary" type="submit">Add category</button></div>
        </form>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/categories/index.blade.php ENDPATH**/ ?>