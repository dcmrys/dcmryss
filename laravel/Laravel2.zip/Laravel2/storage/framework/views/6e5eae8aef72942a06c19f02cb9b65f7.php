<?php $__env->startSection('title', 'Membership Applications'); ?>
<?php $__env->startSection('heading', 'Membership Applications'); ?>
<?php $__env->startSection('subtitle', 'Review applications here. Approval creates a pending membership transaction; record payment and approve the transaction to activate the membership.'); ?>
<?php $__env->startSection('actions'); ?>
    <span class="count-pill"><?php echo e($pendingCount); ?> pending</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading">
        <div><h2>Submitted applications</h2><p>Pending applications appear first.</p></div>
        <span class="count-pill"><?php echo e($applications->total()); ?> total</span>
    </div>
    <div class="table-wrap">
        <table class="application-table">
            <thead>
                <tr><th>Applicant</th><th>Reference</th><th>Category</th><th>Phone</th><th>Submitted</th><th>Application status</th><th>Update status</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><div class="member-cell"><span><strong><?php echo e($application->full_name); ?></strong><span class="table-secondary"><?php echo e($application->email); ?></span></span></div></td>
                        <td class="mono"><?php echo e($application->reference_no); ?></td>
                        <td><?php echo e($application->category?->name ?? '—'); ?></td>
                        <td><?php echo e($application->phone ?: '—'); ?></td>
                        <td><?php echo e($application->created_at?->format('M j, Y g:i A') ?? '—'); ?></td>
                        <td><span class="badge badge-<?php echo e(\Illuminate\Support\Str::slug($application->status)); ?>"><?php echo e(ucfirst($application->status)); ?></span></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('applications.status', $application)); ?>" class="application-status-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <label class="sr-only" for="application-status-<?php echo e($application->id); ?>">Application status for <?php echo e($application->full_name); ?></label>
                                <select id="application-status-<?php echo e($application->id); ?>" name="status">
                                    <?php $__currentLoopData = ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>" <?php if(old('status', $application->status) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button class="btn btn-secondary btn-small" type="submit">Update status</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7"><div class="empty-state"><span>—</span><h3>No applications yet</h3><p>New applications submitted through the public form will appear here.</p></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($applications->hasPages()): ?>
        <div class="pagination">
            <span>Showing <?php echo e($applications->firstItem()); ?>–<?php echo e($applications->lastItem()); ?> of <?php echo e($applications->total()); ?></span>
            <div>
                <?php if($applications->previousPageUrl()): ?><a href="<?php echo e($applications->previousPageUrl()); ?>">← Previous</a><?php endif; ?>
                <?php if($applications->nextPageUrl()): ?><a href="<?php echo e($applications->nextPageUrl()); ?>">Next →</a><?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/membership/index.blade.php ENDPATH**/ ?>