
<?php ($editing = $member->exists); ?>
<?php $__env->startSection('title', $editing ? 'Edit member' : 'Add member'); ?>
<?php $__env->startSection('heading', $editing ? 'Edit member' : 'Add a member'); ?>
<?php $__env->startSection('subtitle', $editing ? 'Update personal details, category, or membership level.' : 'Choose a category and level while registering a member.'); ?>
<?php $__env->startSection('actions'); ?><a class="btn btn-outline" href="<?php echo e($editing ? route('members.show', $member) : route('members.index')); ?>">← Back</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e($editing ? route('members.update', $member) : route('members.store')); ?>" class="form-layout">
    <?php echo csrf_field(); ?>
    <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="form-main">
        <section class="panel form-panel">
            <div class="section-heading"><span class="section-icon">01</span><div><h2>Personal information</h2><p>Basic details used for the member profile.</p></div></div>
            <div class="form-grid">
                <label class="field"><span>First name <em>*</em></span><input name="first_name" value="<?php echo e(old('first_name', $member->first_name)); ?>" required maxlength="100" autocomplete="given-name"></label>
                <label class="field"><span>Last name <em>*</em></span><input name="last_name" value="<?php echo e(old('last_name', $member->last_name)); ?>" required maxlength="100" autocomplete="family-name"></label>
                <label class="field"><span>Email address <em>*</em></span><input name="email" type="email" value="<?php echo e(old('email', $member->email)); ?>" required autocomplete="email"></label>
                <label class="field"><span><?php echo e($editing ? 'New sign-in password' : 'Sign-in password'); ?> <?php if (! ($editing)): ?><em>*</em><?php endif; ?></span><input name="password" type="password" minlength="8" maxlength="255" <?php if (! ($editing)): ?> required <?php endif; ?> autocomplete="new-password"><small><?php echo e($editing ? ($member->user_id ? 'Leave blank to keep the current password.' : 'Set a password to enable sign-in for this existing member.') : 'Share this password securely with the member.'); ?></small></label>
                <label class="field"><span>Phone number</span><input name="phone" value="<?php echo e(old('phone', $member->phone)); ?>" autocomplete="tel"></label>
                <label class="field full"><span>Address</span><textarea name="address" rows="2"><?php echo e(old('address', $member->address)); ?></textarea></label>
            </div>
        </section>

        <section class="panel form-panel">
            <div class="section-heading"><span class="section-icon">02</span><div><h2>Membership details</h2><p>Select one of the provided categories and levels.</p></div></div>
            <div class="form-grid">
                <label class="field"><span>Category <em>*</em></span><select name="membership_category_id" required><option value="">Select category</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category->id); ?>" <?php if(old('membership_category_id', $member->membership_category_id) == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                <label class="field"><span>Level <em>*</em></span><select name="membership_level_id" required><option value="">Select level</option><?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($level->id); ?>" <?php if(old('membership_level_id', $member->membership_level_id) == $level->id): echo 'selected'; endif; ?>><?php echo e($level->name); ?> · ₱<?php echo e(number_format($level->fee, 2)); ?> / <?php echo e($level->validity_months); ?> months</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                <label class="field full"><span>Internal notes</span><textarea name="notes" rows="3" placeholder="Optional context for your team"><?php echo e(old('notes', $member->notes)); ?></textarea></label>
            </div>
        </section>

        <div class="form-actions"><a class="btn btn-outline" href="<?php echo e($editing ? route('members.show', $member) : route('members.index')); ?>">Cancel</a><button class="btn btn-primary" type="submit"><?php echo e($editing ? 'Save changes' : 'Register member'); ?> <span>→</span></button></div>
    </div>

    <aside class="form-aside">
        <div class="info-card">
            <div class="info-card-icon">✦</div>
            <h3>Membership levels</h3>
            <p><?php echo e($editing ? 'For an established member, changing the level creates a renewal transaction; the new level and dates apply after payment and approval. For a pending applicant, it updates the application transaction.' : 'The selected level starts today when the member is registered and an initial transaction is recorded.'); ?> Fees are shown for reference.</p>
            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="plan-option">
                    <div><strong><?php echo e($level->name); ?></strong><span>₱<?php echo e(number_format($level->fee, 2)); ?> · <?php echo e($level->validity_months); ?> months</span></div>
                    <p><?php echo e($level->benefits ?: 'Benefits to be announced.'); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </aside>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/members/form.blade.php ENDPATH**/ ?>