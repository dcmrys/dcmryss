<?php $__env->startSection('title', 'Membership Levels'); ?>
<?php $__env->startSection('heading', 'Membership Levels'); ?>
<?php $__env->startSection('subtitle', 'Set each level’s fee, validity period, and benefits. Members choose a level during registration.'); ?>

<?php $__env->startSection('content'); ?>
<div class="catalog-grid">
    <section class="panel catalog-section">
        <div class="panel-heading">
            <div><h2>Provided levels</h2><p>Update plan details as your membership program changes.</p></div>
            <span class="count-pill"><?php echo e($levels->count()); ?> total</span>
        </div>
        <div class="catalog-list">
            <?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="catalog-item">
                    <form method="POST" action="<?php echo e(route('levels.update', $level)); ?>" class="catalog-form">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="catalog-item-top"><span class="level-symbol">✦</span><span class="catalog-meta"><?php echo e($level->members_count); ?> <?php echo e(Str::plural('member', $level->members_count)); ?></span></div>
                        <label class="field"><span>Level name</span><input name="name" value="<?php echo e($level->name); ?>" required maxlength="100"></label>
                        <div class="form-grid">
                            <label class="field"><span>Fee (₱)</span><input name="fee" type="number" min="0" max="99999999.99" step="0.01" value="<?php echo e($level->fee); ?>" required></label>
                            <label class="field"><span>Validity (months)</span><input name="validity_months" type="number" min="1" max="120" step="1" value="<?php echo e($level->validity_months); ?>" required></label>
                        </div>
                        <label class="field"><span>Benefits</span><textarea name="benefits" rows="4" maxlength="2000" placeholder="One benefit per line"><?php echo e($level->benefits); ?></textarea></label>
                        <div class="form-actions"><button class="btn btn-secondary btn-small" type="submit">Save changes</button></div>
                    </form>
                    <?php if($level->members_count === 0): ?>
                        <form method="POST" action="<?php echo e(route('levels.destroy', $level)); ?>" class="catalog-delete" onsubmit="return confirm('Delete this membership level?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-link">Delete level</button>
                        </form>
                    <?php else: ?>
                        <p class="catalog-use-note">In use by members · cannot be deleted</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="empty-card">No levels yet. Add one using the form.</p>
            <?php endif; ?>
        </div>
    </section>

    <section class="panel form-panel">
        <div class="section-heading"><span class="section-icon">＋</span><div><h2>Add a level</h2><p>Provide its price, duration, and included benefits.</p></div></div>
        <form method="POST" action="<?php echo e(route('levels.store')); ?>" class="stacked-form">
            <?php echo csrf_field(); ?>
            <label class="field"><span>Level name <em>*</em></span><input name="name" value="<?php echo e(old('name')); ?>" required maxlength="100" placeholder="e.g. Diamond"></label>
            <div class="form-grid">
                <label class="field"><span>Fee (₱) <em>*</em></span><input name="fee" type="number" min="0" max="99999999.99" step="0.01" value="<?php echo e(old('fee')); ?>" required></label>
                <label class="field"><span>Validity (months) <em>*</em></span><input name="validity_months" type="number" min="1" max="120" step="1" value="<?php echo e(old('validity_months')); ?>" required></label>
            </div>
            <label class="field"><span>Benefits</span><textarea name="benefits" rows="5" maxlength="2000" placeholder="One benefit per line"><?php echo e(old('benefits')); ?></textarea></label>
            <div class="form-actions"><button class="btn btn-primary" type="submit">Add level</button></div>
        </form>
        <p class="catalog-use-note">Edits to a level affect new registrations. Existing membership expiry dates stay as recorded.</p>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Maryclaire\Desktop\Uni\XAMPP\htdocs\dcmryss\laravel\Laravel2\resources\views/levels/index.blade.php ENDPATH**/ ?>