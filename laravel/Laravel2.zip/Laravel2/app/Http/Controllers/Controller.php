<?php

namespace App\Http\Controllers;

abstract class Controller
{
        
}

// http://127.0.0.1:8000
// http://127.0.0.1:8000/tasks      
// php artisan serve
// php artisan queue:work